# ACTIVIDAD Nº 2

## TÍTULO DE LA ACTIVIDAD: Añadir almacenamiento a un contenedor LXC

## TEXTO DE LA ACTIVIDAD

En esta actividad vamos a seguir trabajando con el contenedor que creamos en la actividad anterior:

1. Añade un volumen de 2Gb como punto de montaje en el contenedor, en el directorio `/srv`.

Para superar la actividad deberás entregar en un fichero comprimido los siguientes pantallazos:

1. Un pantallazo donde se vea el apartado **Resources** del contenedor.
2. Un pantallazo donde se vea el punto de montaje en el contenedor como se muestra en el contenido del tema.


## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

Sí

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se entregan los documentos, contienen lo solicitado y los contenidos son originales.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora
