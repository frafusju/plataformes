# ACTIVIDAD Nº 1

## TÍTULO DE LA ACTIVIDAD: Foro: ¿Qué experiencia previa tienes sobre virtualización?

## TEXTO DE LA ACTIVIDAD

Participar en el foro: **¿Qué experiencia previa tienes sobre virtualización?** contestando las siguientes preguntas:

1. ¿Qué sistema de virtualización utilizas con tus alumnos? ¿En qué módulos utilizas la virtualización?
2. ¿Qué ventajas te aporta la virtualización a la hora de impartir tus materias? ¿Y desventajas?
3. A priori, y sin haber realizado este curso. ¿Qué ventajas piensas que puede aportar el uso de Proxmox VE a tu trabajo como docente?
4. Quizás ya lo estéis usando en vuestro instituto, pero si no es así, ¿existe planes en vuestro departamento para instalar un servidor Proxmox y dar servicio a los alumnos?


## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

Sí

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se responden las preguntas de manera adecuada.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora