# ACTIVIDAD Nº 3

## TÍTULO DE LA ACTIVIDAD: Gestión de discos 

## TEXTO DE LA ACTIVIDAD

Seguimos trabajando con la máquina de la actividad anterior. Vamos a modificar las características del disco que hemos añadido:

1. Redimensiona el disco a 2Gb.
2. Accede a la máquina y redimensiona el sistema de ficheros como se ha mostrado en el contenido del módulo.
3. Mueve el contenido del disco al almacenamiento `local-lvm`.

Para superar la actividad deberás entregar en un fichero comprimido los siguientes pantallazos:

1. Un pantallazo donde se vea el apartado **Hardware** de la máquina creada para comprobar que hemos redimensionado el disco a 2Gb.
4. Un pantallazo donde sea vea que el sistema de ficheros montado en `/mnt` se ha redimensionado también.
5. Un pantallazo donde se vea el apartado **Hardware** de la máquina creada para comprobar que el disco se ha movido de la fuente de almacenamiento.

## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

No

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se entregan los documentos, contienen lo solicitado y los contenidos son originales.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora