# Gestión de imágenes ISO

Antes de crear una máquina virtual, necesitamos subir las imágenes
ISO-9660 de los sistemas operativos desde los que vamos a crear las
máquinas. Para ello en el almacenamiento *local*, seleccionamos la
opción *ISO images* y subimos los ficheros que necesitemos:

![iso](img/subir_iso.png)

También tenemos la posibilidad de indicar una URL para descargar la
ISO y de borrar una determinada ISO.

Finalmente podremos ver la  lista de imágenes ISO que hemos subido a
nuestro Proxmox VE:

![iso](img/iso.png)
