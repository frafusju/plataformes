# ACTIVIDAD Nº 2

## TÍTULO DE LA ACTIVIDAD: Trabajando con plantillas

## TEXTO DE LA ACTIVIDAD

1. Elige una máquina que tengas creada y conviértela a una plantilla.
2. A partir de la plantilla crea una nueva máquina utilizando la clonación ligera.

Para superar la tarea deberás entregar un documento con los siguientes pantallazos:

1. Un pantallazo donde se vea el apartado **Hardware** de la máquina original.
2. Un pantallazo donde se vea que has creado la plantilla.
3. Un pantallazo donde se vea el apartado **Hardware** de la máquina clonada.

## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

Sí

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se entregan los documentos, contienen lo solicitado y los contenidos son originales.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora