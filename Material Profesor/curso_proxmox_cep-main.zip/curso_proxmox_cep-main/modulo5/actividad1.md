# ACTIVIDAD Nº 1

## TÍTULO DE LA ACTIVIDAD: Clonación de máquinas virtuales

## TEXTO DE LA ACTIVIDAD

1. Elige una máquina que tengas creada y realiza una clonación para crear una nueva máquina. La clonación se debe hacer sobre la fuente de almacenamiento distinto al que usaba la máquina original.

Para superar la tarea deberás entregar un documento con los siguientes pantallazos:

1. Un pantallazo donde se vea el apartado **Hardware** de la máquina original.
2. Un pantallazo donde se vea el apartado **Hardware** de la máquina clonada.

## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

Sí

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se entregan los documentos, contienen lo solicitado y los contenidos son originales.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora