# ACTIVIDAD Nº 4

## TÍTULO DE LA ACTIVIDAD: Copias de seguridad de máquinas virtuales

## TEXTO DE LA ACTIVIDAD

1. Crea una copia de seguridad de una máquina.
2. Muestra la lista de copias de seguridad realizadas.
3. Crea una nueva máquina a partir de la copia de seguridad realizada.

Para superar la tarea deberás entregar un documento con los siguientes pantallazos:

1. Un pantallazo donde se muestre la copia de seguridad creada.
2. Un pantallazo donde se vea el apartado **Hardware** de la máquina original.
3. Un pantallazo donde se vea el apartado **Hardware** de la máquina creada a partir de la copia de seguridad.

## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

No

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se entregan los documentos, contienen lo solicitado y los contenidos son originales.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora