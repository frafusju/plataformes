# ACTIVIDAD Nº 3

## TÍTULO DE LA ACTIVIDAD: Snapshots de máquinas virtuales

## TEXTO DE LA ACTIVIDAD

1. Crea un fichero de texto en una máquina con cualquier información.
2. Crea un snapshot de la máquina.
3. Modifica el contenido del fichero creado.
4. Restaura el estado de la máquina con el snapshot creado.

Para superar la tarea deberás entregar un documento con los siguientes pantallazos:

1. Un pantallazo donde se vea el contenido del fichero.
2. Un pantallazo donde se vea que se ha creado un snapshot.
3. Un pantallazo donde se vea la modificación del fichero.
4. Un pantallazo donde se muestre la información del fichero después de recuperar el estado de la máquina con el snapshot creado.


## RECURSOS

* Conexión a Internet

## ¿ES OBLIGATORIO HACER ESTA ACTIVIDAD PARA SUPERAR EL CURSO? (S/N)

No

## ¿ES UNA ACTIVIDAD INDIVIDUAL O DE GRUPO?

Individual

## ¿ES UNA ACTIVIDAD CALIFICABLE?

Sí

### ¿Tiene que ser calificada por el tutor/a? (S/N)

Sí

### ¿Es de calificación automática?

No

### ¿Es calificada por el resto de compañeros/as del curso? (S/N)

No

## EVALUACIÓN

* Se entregan los documentos, contienen lo solicitado y los contenidos son originales.

## ¿ES NECESARIO TENER TERMINADA ALGUNA ACTIVIDAD O RECURSO ANTERIOR? Indique cuáles.

No

## TIEMPO ESTIMADO PARA REALIZAR LA ACTIVIDAD

1 hora
